#coding:utf8
from django.shortcuts import render,HttpResponseRedirect,HttpResponse

# Create your views here.
from django.db.models import Q  # 单独创建一个查询条件
from django.core.paginator import Paginator,InvalidPage,EmptyPage,PageNotAnInteger
from django.contrib.auth.models import User # 内置用户表
from django.core.urlresolvers import reverse
from django.contrib.auth.hashers import make_password # 用户密码加密
from django.contrib.auth.decorators import login_required
from django.contrib import auth
from django.views.generic import View,ListView
from forms import ClsForm
from django.conf import settings
import os
import uuid

import models

def upload_avatar(file):
    file_type = file.content_type
    file_name = file.name
    file_size = file.size

    if file_size / 1024 /1024 < 2: # 小于2M
        if file_type == 'image/jpeg' or file_type == 'image/gif':
            uname = str(uuid.uuid4()) + '.jpg' # 生成唯一name
            filepath = os.path.join(settings.BASE_DIR, 'upload') + '/avatar/' + uname
            dbpath = 'avatar/' + uname # 数据库中存在的路径

            if file.multiple_chunks(): # 文件是否过大 2.5M 标准
                with open(filepath,'wb') as f:
                    for chunk in file.chunks():
                        f.write(chunk)

            else: #正常大小情况

                with open(filepath,'wb') as f :
                    file_content = file.read()
                    f.write(file_content)
            return True,'上传成功',dbpath

        else:
            return False, '格式不正确，什么正确的，自己想去'

    else:
        return False,'照片不能超过2M'


# 学生添加
@login_required
def index(request):
    groups_list = models.Group.objects.all()

    if request.method == 'POST': # 添加操作
        name = request.POST.get('name',None)
        age = request.POST.get('age',None)
        score = request.POST.get('score',None)
        cid = request.POST.get('cid',None)
        groups = request.POST.getlist('groups') #列表

        avatar = request.FILES.get('avatar')
        res = upload_avatar(avatar)

        if res[0] is True: # 判断文件是否上传成功

            stu_info = {
                'name' : name,
                'age' : age,
                'score' : score,
                'cls_id' : cid,
                'avatar' : res[2],
            }
            try:
                s = models.Student.objects.create(**stu_info)
                s.group.add(*groups)
                s.save()
                return HttpResponseRedirect('/manage/')

            except Exception,e:
                return HttpResponse('请好好填写，数据格式不正确，添加失败')
        else:
            return render(request,'homework/index.html', {'error' : res[1] ,'group_list':groups_list})

    elif request.method == "GET":
        classes = models.Class.objects.all()
        context = {
            'index' : 'active',
            'classes' : classes,
            'group_list' : groups_list,
        }
        return render(request,'homework/index.html',context)



#学生管理
@login_required
def manage(request):
    order = request.GET.get('order',None)
    rule = request.GET.get('rule',None)
    pn = request.GET.get('pn',1)

    try:
        pn = int(pn)
    except:
        pn = 1

    # 搜索
    keyword = request.GET.get('keyword','')
    if keyword is not None:
        # # 用集合操作符
        # stus1 = models.Student.objects.filter(name__icontains=keyword).all()
        # stus2 = models.Student.objects.filter(age__icontains=keyword).all()
        # stus = stus1 | stus2

        # django 里进行条件合并,组合条件查询
        condition = Q(name__icontains=keyword) | Q(age__icontains=keyword) | Q(cls__name__icontains=keyword)
        stus = models.Student.objects.filter(condition).all()
    else:
        stus = models.Student.objects.all()

    # 排序
    if order is not None: # 排序字段不为空
        if order == '':
            order = 'id'
        if rule == 'up':
            stus = stus.order_by(order) # 升序
        elif rule == 'down':
            stus = stus.order_by('-' + order) #降序

    # 分页
    paginator = Paginator(stus,2) # a1:查询结果集  a2：每页显示记录数
    try:
        stus = paginator.page(pn) # 获取某一页记录
    except (EmptyPage,InvalidPage,PageNotAnInteger) as e:
        pn = 1
        stus = paginator.page(pn)

    # 获取总页数
    num_pages = stus.paginator.num_pages

    # 分页数字实现
    # 显示5个数字，当前页数字放在中间（高亮显示）
    if num_pages >= 5: # 总页数大于你想要显示的分页数字
        if pn <= 2:
            start = 1
            end = 6
        elif pn > num_pages - 2:  # 10页  pn:9
            start = num_pages - 4
            end = num_pages + 1
        else:
            start = pn - 2
            end = pn + 3
    else:
        start = 1
        end = num_pages + 1

    numbers = range(start , end)

    context = {
        'manage' : 'active',
        'stus': stus,
        'num_pages' : num_pages,
        'numbers' : numbers,
        'pn' : pn,
    }
    return render(request,'homework/manage.html',context)

def config(request):
    context = {
        'config' : 'active'
    }
    return render(request,'homework/config.html',context)

def stu_del(request):
    # 获取学生id
    sid = request.GET.get('sid',None)
    if sid is not None:
        sid = int(sid)
        res = models.Student.objects.filter(id=sid).delete()
        if res != 0:
            return HttpResponseRedirect('/manage/')
        else:
            return HttpResponse('删除失败，数据异常')
    else:
        return HttpResponse('数据异常')

# 学生修改视图函数
def stu_edit(request):
    sid = request.GET.get('sid', None) #  获取学生id
    stu = models.Student.objects.get(pk=sid)  # 获取修改哪个学生

    group_list = models.Group.objects.all()  # 所有小组

    if request.method == 'POST': # 修改操作
        name = request.POST.get('name',None)
        age = request.POST.get('age',None)
        score = request.POST.get('score',None)
        cid = request.POST.get('cid',None)
        groups = request.POST.getlist('groups') #列表
        avatar = request.FILES.get('avatar')
        res = upload_avatar(avatar)
        if res[0]:
            stu_info = {
                'name' : name,
                'age' : age,
                'score' : score,
                'cls_id' : cid,
                'avatar' : res[2],
            }
            try:
                res = models.Student.objects.filter(pk=sid).update(**stu_info)
                if res != 0:
                    stu.group.clear()
                    stu.group.add(*groups)
                    return HttpResponseRedirect('/manage/')
                else:
                    return HttpResponse('修改失败')

            except Exception,e:
                print e
                return HttpResponse('请好好填写，数据格式不正确，修改失败')
        else:
            return render(request,'homework/edit.html',{'group_list':group_list,'error':res[1]})

    elif request.method == "GET":

        classes = models.Class.objects.all() # 所有班级

        # 上下文字典
        context = {
            'classes' : classes,
            'group_list' : group_list,
            'stu': stu,
        }
        return render(request,'homework/edit.html',context)

# 用户登陆业务逻辑处理
def login(request):
    if request.method == 'POST':
        error = ''
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        # print username,password
        if username and password: # 验证用户名和密码是否为空
            user = auth.authenticate(username=username,password=password) #如果验证成功，返回用户实例.不成功返回None
            if user is not None: # 用户存在
                if user.is_active: # 判断用户是否激活状态
                    # 用户登陆
                    auth.login(request,user)
                    # 登陆成功
                    to_url = reverse('manage')
                    return HttpResponseRedirect(to_url)
            else:
                error = '用户名或密码错误'
                return render(request,'user/login.html',{'error':error})

        else:
            error = '用户名或密码不能为空'
            return render(request,'user/login.html',{'error' : error})

    elif request.method == 'GET':
        return render(request,'user/login.html')

# 用户注册
def reg(request):
    # 获取用户注册信息
    username = request.POST.get('username',None)
    password1 = request.POST.get('password1',None)
    password2 = request.POST.get('password2',None)
    nick = request.POST.get('nick','匿名')
    qq = request.POST.get('qq','')
    phone = request.POST.get('phone','')

    if username and password1 and password2: #有点不能为空
        if password1 == password2: # 密码确认验证
            uc = User.objects.filter(username=username).all().count() # 验证用户名是否存在
            if uc == 0: #用户名不存在
                user_info = {
                    'username' : username,
                    'password' : make_password(password1),
                    'is_active' : 1,
                    'is_superuser' : 0,
                    'is_staff' : 1,
                }
                # 插入django内置用户表
                user = User.objects.create(**user_info)

                # 插入用户扩展信息表
                profile_info = {
                    'nick' : nick,
                    'user' : user,
                    'qq' : qq,
                    'phone' : phone,
                }
                try:
                    models.UserProfile.objects.create(**profile_info)
                    # 注册成功 则跳转
                    to_url = reverse('login')
                    return HttpResponseRedirect(to_url)

                except Exception,e:
                    error = '系统繁忙'
                    return render(request, 'user/reg.html', {'error': error})

            else:
                #用户名存在
                error = '用户名已被注册，想一个更好的吧，你太low了'
                return render(request, 'user/reg.html', {'error': error})
        else:
            error = '两次密码不相同'
            return render(request, 'user/reg.html', {'error': error})
    else:
        error = '用户名密码不能为空'
        return render(request,'user/reg.html',{'error':error})

# 用户退出
def logout(request):
    auth.logout(request)
    to_url = reverse('login')
    return HttpResponseRedirect(to_url)


# 班级添加管理 -- 手写form
# class ClsAdd(View):
#     # 直接处理GET 请求
#     def get(self,request):
#         context = {
#             'cls_add' : 'active',
#         }
#         return render(request,'cls/cls_add.html',context)
#
#     # 处理POST 请求
#     def post(self,request):
#         name = request.POST.get('name',None)
#         print name
#         if name is not None and name != '':
#             cls = models.Class.objects.create(name=name)
#             return HttpResponseRedirect(reverse('cls_manage'))
#         else:
#             return render(request,'cls/cls_add.html',{'error':'班级名不能为空'})

# 班级添加管理，django -form
class ClsAdd(View):
    # 直接处理GET 请求
    def get(self,request):
        clsform = ClsForm() # 实例化表单对象
        context = {
            'cls_add' : 'active',
            'clsform' : clsform
        }
        return render(request,'cls/cls_add.html',context)

    # 处理POST 请求
    def post(self,request):
        clsform = ClsForm(request.POST)  # 实例化表单对象
        if clsform.is_valid(): # 表单数据验证
            clsform.save() # 插入数据
            return HttpResponseRedirect(reverse('cls_manage'))
        else:# 表单数据有问题（不合法）
            context = {
                'error': '表单数据不合法',
                'clsform': clsform,
                'cls_add' : 'active',
            }
            return render(request,'cls/cls_add.html',context)

class ClsEdit(View):
    # 直接处理GET 请求
    def get(self,request):
        cid = request.GET.get('cid',None)
        try:
            cls = models.Class.objects.get(pk=cid)  # 查询一个班级
        except Exception,e:
            return HttpResponseRedirect(reverse('cls_manage'))
        context = {}
        context['cls_add'] = 'active'
        if cid is not None: # 获取班级ID
            clsform = ClsForm(instance=cls) # 实例化表单对象 填充form表单
            context['clsform'] = clsform
            return render(request,'cls/cls_edit.html',context)
        else:
            clsform = ClsForm(instance=cls) # 实例化表单对象 填充form表单
            context['clsform'] = clsform
            context['error'] = '班级ID不存在'
            return render(request,'cls/cls_edit.html',context)

    # 处理POST 请求
    def post(self,request):
        clsform = ClsForm(request.POST)  # 实例化表单对象
        if clsform.is_valid(): # 表单数据验证
            clsform.save() # 插入数据
            return HttpResponseRedirect(reverse('cls_manage'))
        else:# 表单数据有问题（不合法）
            context = {
                'error': '表单数据不合法',
                'clsform': clsform,
            }
            return render(request,'cls/cls_edit.html',context)


# 班级列表管理
# class ClsManage(View):
#     def get(self,request):
#         context = {
#             'cls_manage' : 'active',
#         }
#         return render(request,'cls/cls_manage.html',context)


# 视图列表
class ClsManage(ListView):
    template_name = 'cls/cls_manage.html'
    context_object_name = 'cls_list'
    # 自动分配模板变量
    def get_queryset(self): # 需要返回查询数据集
        c = models.Class.objects.get(pk=1)
        return models.Class.objects.all()

    # 自定义模板变量
    def get_context_data(self, **kwargs):
        context = super(ClsManage, self).get_context_data(**kwargs) # 生成上下文对象
        context['cls_manage'] = 'active'
        return context



