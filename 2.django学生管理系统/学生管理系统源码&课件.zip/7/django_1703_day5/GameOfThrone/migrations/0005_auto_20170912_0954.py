# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('GameOfThrone', '0004_auto_20170912_0919'),
    ]

    operations = [
        migrations.AlterField(
            model_name='class',
            name='name',
            field=models.CharField(unique=True, max_length=20, verbose_name=b'\xe7\x8f\xad\xe7\xba\xa7\xe5\x90\x8d'),
        ),
    ]
