# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('GameOfThrone', '0005_auto_20170912_0954'),
    ]

    operations = [
        migrations.AddField(
            model_name='class',
            name='email',
            field=models.EmailField(default='', max_length=b'30', verbose_name=b'\xe7\x8f\xad\xe7\xba\xa7\xe9\x82\xae\xe7\xae\xb1'),
            preserve_default=False,
        ),
    ]
