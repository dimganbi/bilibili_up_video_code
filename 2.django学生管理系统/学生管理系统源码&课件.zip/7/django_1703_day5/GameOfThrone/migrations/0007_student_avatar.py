# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('GameOfThrone', '0006_class_email'),
    ]

    operations = [
        migrations.AddField(
            model_name='student',
            name='avatar',
            field=models.ImageField(default=b'avatar.jpg', upload_to=b'./static/avatar/', max_length=b'100', verbose_name=b'\xe7\x85\xa7\xe7\x89\x87'),
        ),
    ]
