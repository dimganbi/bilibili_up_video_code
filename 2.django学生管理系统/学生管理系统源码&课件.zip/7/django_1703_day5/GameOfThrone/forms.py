#coding:utf8
from django import forms
from models import Class,Student,Group

# 一个表单类
class ClsForm(forms.ModelForm):
    class Meta:
        model = Class
        fields = ['name','email']
        # 自定义表单项 ，表单项属性
        widgets = {
            'name' : forms.TextInput(attrs={'class':'form-control','placeholder':'班级名称','name':'name'}),
            'email' : forms.EmailInput(attrs={'class':'form-control','placeholder':'班级邮箱','name':'email'})
        }