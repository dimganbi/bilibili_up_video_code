# coding:utf8
from django.contrib import admin

# Register your models here.

import models

class StuAdmin(admin.ModelAdmin):
    # 详情页
    fieldsets = [
        ('基本', {'fields': ['name','age']}),
        ('高级', {'fields': ['score','cls'], 'classes': ['collapse']}),
    ]

    # 列表也展示（列表页）
    list_display = ['name','age','score','cls','email']

    # 搜索 条件
    search_fields = ['name','age','cls__name']

    # 高级搜索，过滤条件
    list_filter = ['name','score','cls__name']


admin.site.register(models.Student,StuAdmin)
admin.site.register(models.Class)
admin.site.register(models.Group)