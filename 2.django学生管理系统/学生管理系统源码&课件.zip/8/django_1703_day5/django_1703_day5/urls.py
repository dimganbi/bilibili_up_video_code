#coding:utf8
"""django_1703_day5 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from django.contrib import admin
from GameOfThrone import views
from cookie import views as cookie_views
from polls import views as polls_views
from django.views.static import serve # 处理媒体文件
from django.conf import settings
import os


urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    url(r'^$', views.index,name='index'),
    url(r'^manage/$', views.manage,name='manage'),
    url(r'^config/$', views.config,name='config'),
    url(r'^stu_del/$', views.stu_del,name='stu_del'),
    url(r'^stu_edit/$', views.stu_edit,name='stu_edit'),

    url(r'^cls_add/$', views.ClsAdd.as_view(),name='cls_add'), # 视图类
    url(r'^cls_edit/$', views.ClsEdit.as_view(),name='cls_edit'),
    url(r'^cls_manage/$', views.ClsManage.as_view(),name='cls_manage'),


    url(r'^login/$', views.login,name='login'),
    url(r'^reg/$', views.reg,name='reg'),
    url(r'^logout/$', views.logout , name='logout'),

    # 媒体文件处理
    url(r'^upload/(.*)' , serve ,{'document_root': os.path.join(settings.BASE_DIR,'upload') }),

    url(r'^cookie/' , cookie_views.index),
    url(r'^get_cookie/' , cookie_views.get_cookie),
    url(r'^foo/' , cookie_views.foo),

    # 投票url
    url(r'^polls/' , polls_views.index),
    url(r'^polls_detail/(?P<qid>\d+)/' , polls_views.polls_detail,name='polls_detail'),
    url(r'^polls_result/(?P<qid>\d+)/' , polls_views.polls_result,name='polls_result'),
]
