#coding:utf8
from django.shortcuts import render,HttpResponse,HttpResponseRedirect
from django.core.urlresolvers import reverse
# Create your views here.
import models

def index(request):
    question_list = models.Question.objects.all()
    return render(request,'polls/index.html',{'question_list':question_list})

def polls_detail(request,qid):
    if request.method == 'POST':
        is_poll = request.COOKIES.get('is_poll',None)
        if is_poll is None:
            #累计票数
            cid = request.POST.get('cid',None)
            if cid is not None: # 投票成功跳转
                choice = models.Choice.objects.get(pk=cid)
                choice.votes = choice.votes + 1
                choice.save()

                rep = HttpResponseRedirect(reverse('polls_result',args=(qid,)))
                rep.set_cookie('is_poll','1')
                return rep
        else: # 以前投过票
            return HttpResponse('你已经投过了，不要刷票')

    else:
        question = models.Question.objects.get(pk=qid)
        return render(request,'polls/detail.html',{'question':question})

def polls_result(request,qid):
    question = models.Question.objects.get(pk=qid)
    return render(request,'polls/result.html',{'question':question})