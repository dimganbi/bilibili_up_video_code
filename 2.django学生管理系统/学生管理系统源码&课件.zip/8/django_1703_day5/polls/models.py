#coding:utf8
from django.db import models

# Create your models here.

#投票主题
class Question(models.Model):
    question_text = models.CharField(verbose_name='投票标题',max_length=30)
    date_add = models.DateTimeField(auto_now_add=True)

    def __unicode__(self):
        return self.question_text

#投票选项
class Choice(models.Model):
    choice_text = models.CharField(verbose_name='选项标题',max_length=30)
    votes = models.IntegerField(verbose_name='票数',default=0)
    question = models.ForeignKey('Question')

    def __unicode__(self):
        return self.choice_text