from django.contrib import admin
import models

# Register your models here.

class ChoiceInline(admin.StackedInline):
    model = models.Choice
    extra = 4

class QuestionAdmin(admin.ModelAdmin):
    inlines = [ChoiceInline]

admin.site.register(models.Question,QuestionAdmin)
admin.site.register(models.Choice)