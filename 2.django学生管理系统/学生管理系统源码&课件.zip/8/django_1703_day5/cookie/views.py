#coding:utf8
from django.shortcuts import render,HttpResponse

# Create your views here.

def index(request):
    rep = HttpResponse('set cookie') # 返回响应对象
    # 设置cookie
    # rep.set_cookie('name','alice',max_age=3600*24,path='/') # max_age 设置过期时间
    # rep.set_cookie('age','18',max_age=3600*24,path='/')
    # return rep

    # 设置签名cookie
    rep.set_signed_cookie('name','alice',salt='abcd')
    rep.set_signed_cookie('age','18',salt='abcd')
    return rep

# 获取cookie
def get_cookie(request):
    # 获取普通cookie
    # username = request.COOKIES.get('name',None)
    # age = request.COOKIES.get('age')
    # return HttpResponse('欢迎%s登陆 年龄%s' % (username ,age))

    # 获取签名cookie
    username = request.get_signed_cookie('name',salt='abcd')
    return HttpResponse('欢迎%s登陆' % (username))

def foo(request):
    username = request.COOKIES.get('name',)
    return HttpResponse('欢迎%s登陆' % (username,))