#coding:utf8
from django import forms
from models import Class,Student,Group
from GameOfThrone.models import Class

# 一个表单类
class ClsForm(forms.ModelForm):
    class Meta:
        model = Class
        fields = ['name','email']
        # 自定义表单项 ，表单项属性
        widgets = {
            'name' : forms.TextInput(attrs={'class':'form-control','placeholder':'班级名称','name':'name'}),
            'email' : forms.EmailInput(attrs={'class':'form-control','placeholder':'班级邮箱','name':'email'})
        }

class SubTextInput(forms.TextInput):
    class Media:
        css = {
            'all' : ('common/css/text_input.css',)
        }


# 学生表单
class StuForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['name','age']

        widgets = {
            'name' : forms.Textarea(attrs={'cols':100,'rows':10}),
            'age' : SubTextInput(),
        }

# 批量修改班级表单

class SetClsForm(forms.Form):
    # <input value=>   cls_choice = [(1,'1703'),()]
    cls_choice = Class.objects.all().values_list('id','name')
    cls = forms.ChoiceField(choices=cls_choice) # 下拉列表
    _selected_action = forms.CharField(widget=forms.MultipleHiddenInput)