# coding:utf8
from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin
from GameOfThrone.forms import StuForm,SetClsForm
from django.shortcuts import render
# Register your models here.

import models

class MyUserAdmin(UserAdmin):
    # 配置显示列字段
    list_display = ['username','first_name','email','is_superuser','is_staff','is_active']

class StuAdmin(admin.ModelAdmin):
    form = StuForm # 指定后台form widget 控件表单

    # 自定义action
    def print_stu(self, request, queryset):
        for item in queryset:
            print item.name

    # 批量修改班级
    # def setClsAction(self, request, queryset):
    #     for item in queryset:
    #         item.cls_id = 2
    #         item.save()
    def setClsAction(self, request, queryset):
        if request.POST.get('post'): # 批量修改班级的实际操作
            clsform = SetClsForm(request.POST)
            if clsform.is_valid(): # 数据验证
                cls = clsform.cleaned_data['cls']
                for item in queryset:
                    item.cls_id = cls
                    item.save()
            self.message_user(request,'%d 个学生被改成班级id : %d' % (len(queryset),int(cls)))

        else: # 渲染中间页表单
            context = {
                'form' : SetClsForm(initial={'_selected_action': request.POST.getlist(admin.ACTION_CHECKBOX_NAME)})
            }
            return render(request,'common/setcls.html',context)


    setClsAction.short_description = '批量修改班级'
    actions = [print_stu,setClsAction]

    # 详情页
    fieldsets = [
        ('基本', {'fields': ['name','age']}),
        ('高级', {'fields': ['score','cls'], 'classes': ['collapse']}),
    ]

    # 列表也展示（列表页）
    list_display = ['name','age','score','cls','email']

    # 列表项可编辑 （不能和list_display_links 相同）
    list_editable = ['score','email','cls']

    # 点列可以进入详情页
    list_display_links = ['name','age']

    # 搜索 条件
    search_fields = ['name','age','cls__name']

    # 高级搜索，过滤条件
    list_filter = ['name','score','cls__name']

    change_form_template = 'common/change_form.html'


admin.site.register(models.Student,StuAdmin)
admin.site.register(models.Class)
admin.site.register(models.Group)

admin.site.unregister(User) #反注册
admin.site.register(User,MyUserAdmin) # 再注册