/**
 * Created by Tina on 2017/9/6 006.
 */

console.log('加入我们把！！！！！！！，月薪100000k')